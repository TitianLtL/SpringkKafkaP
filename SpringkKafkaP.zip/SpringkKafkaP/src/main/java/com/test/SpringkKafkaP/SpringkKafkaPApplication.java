package com.test.SpringkKafkaP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringkKafkaPApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringkKafkaPApplication.class, args);
	}

}
